def greet(name):
    print("Hello,{} Good Morning!!!".format(name))