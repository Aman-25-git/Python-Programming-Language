#MathsInfo.py<---File Name<---acts as Module Name
PI=3.14
E=2.71  # Here PI and E are Called Global Variables
bname="SBI"

