#Temp.py<---File Name and Module Name
import sys
def  tempconcersion():
	s="""---------------------------------------------------
				Temp Conversion Calculator
	---------------------------------------------------
				1. C to F
				2. C to K
				3. F to C
				4. F to K
				5. K to F
				6. K to C
				7. Exit
	---------------------------------------------------"""
	print(s)
	ch=int(input("Enter UR Choice:"))
	match(ch):
		case 1:
			C=float(input("Enter the Temp in C Terms:"))
			F = C * (9 / 5) + 32
			print("Temp in C terms=",C)
			print("Temp in F terms=", F)
		case 2:
			C = float(input("Enter the Temp in C Terms:"))
			K = C + 273.15
			print("Temp in C terms=", C)
			print("Temp in K terms=", K)
		case 3:
			F = float(input("Enter the Temp in F Terms:"))
			C = (F-32)*(5/9)
			print("Temp in F terms=", F)
			print("Temp in C terms=", C)
		case 4:
			F = float(input("Enter the Temp in F Terms:"))
			K = (F-32)* (5/9) + 273.15
			print("Temp in F terms=", F)
			print("Temp in K terms=", K)
		case 5:
			K = float(input("Enter the Temp in K Terms:"))
			F = (K-273.15)*(9/5) + 32
			print("Temp in K terms=", K)
			print("Temp in F terms=", F)
		case 6:
			K = float(input("Enter the Temp in K Terms:"))
			C = K - 273.15
			print("Temp in K terms=", K)
			print("Temp in C terms=", C)
		case 7:
			print("Thx for Using this Program")
			sys.exit()
		case _:
			print("Ur Selection of Operation is wrong-try again")




