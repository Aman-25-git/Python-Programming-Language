#program for cal Roots of Quadratic Equation.
#Quad.py<---Module Name
def getABCValues():
    a=float(input("Enter Value of a:"))
    b = float(input("Enter Value of b:"))
    c = float(input("Enter Value of c:"))
    return a,b,c
def caldet():
    a,b,c=getABCValues()
    d=(b**2-4*a*c)**0.5
    return a,b,c,d
def calroots():
    a,b,c,d=caldet()
    if(type(d)==complex):
        print("Roots Are Imaginary")
        r1=(-b+d)/(2*a)
        r2=(-b-d)/(2*a)
        print("First Root=",r1)
        print("Second Root=",r2)
    else:
        if(d==0):
            print("Roots are Equal")
            r1=-b/(2*a)
            r2=r1
            print("First Root=",r1)
            print("Second Root=",r2)
        else:
            print("Roots are Equal and Distict")
            r1=(-b+d)/(2*a)
            r2=(-b-d)/(2*a)
            print("First Root=", r1)
            print("Second Root=", r2)

